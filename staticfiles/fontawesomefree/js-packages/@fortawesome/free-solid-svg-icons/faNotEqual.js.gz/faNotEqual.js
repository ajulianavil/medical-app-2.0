'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'not-equal';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f53e';
var svgPathData = 'M353.8 37.4c14.7 9.8 18.7 29.7 8.9 44.4L321.1 144H384c17.7 0 32 14.3 32 32s-14.3 32-32 32H278.5l-64 96H384c17.7 0 32 14.3 32 32s-14.3 32-32 32H171.8l-65.2 97.7c-9.8 14.7-29.7 18.7-44.4 8.9s-18.7-29.7-8.9-44.4L94.9 368H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H137.5l64-96H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H244.2l65.2-97.7c9.8-14.7 29.7-18.7 44.4-8.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faNotEqual = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;